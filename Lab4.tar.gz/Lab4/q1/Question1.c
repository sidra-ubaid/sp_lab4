#include<stdio.h>
#include<stdlib.h>
int main()
{
	int i; int size=10;
	int *ID=(int *)malloc(sizeof(int)*size);
	if(ID==NULL)
{
	perror("malloc failed");
}

for(i=0;i<size;i++)
{
	ID[i]=size-1;
}
for(i=0;i<size;i++)
{
	printf("%d, ",ID[i]);
}
printf("\n");
int newsize=20;
int *nptr=(int*)realloc(ID,sizeof(int)*newsize);
if(nptr==NULL)
{
	perror("realloc failed\n");
}
else
	ID=nptr;
int j=0;
for(i=size;i<newsize;i++)
{
	ID[i]=j++;
}
for(i=0;i<newsize;i++)
{
printf("%d ",ID[i]);
}
printf("\n");
free(ID);
return 0;

}
