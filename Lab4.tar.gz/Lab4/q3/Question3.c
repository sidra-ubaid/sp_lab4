#include<stdio.h>
//static jmp_buf envbuf;
#include<setjmp.h>
jmp_buf bufferA;
void haveFun();
void firstSetJump();
int counter;
int main()
{
	
	printf("This is main\n");
	counter=setjmp(bufferA);
	if((counter=setjmp(bufferA))==0)
{
	printf("value of counter before firstSetJump = %d\n", counter);
	firstSetJump();
	
}
else
{
	printf("value of counter before haveFun = %d\n", counter);
	haveFun();
}
printf("This is main again. \n");
printf("Value of counter = %d\n",counter);
return 0;
}
void haveFun()
{
	printf("This is fun()\n");
	counter=counter+1;
	printf("Value of counter in haveFun = %d\n",counter);
	//longjmp(envbuf,52);
}

void firstSetJump()
{
	printf("This is firstSetJump()\n");
	counter=counter+1;
	printf("Value of counter in firstSetJump = %d\n",counter);
}
