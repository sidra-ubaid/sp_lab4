#include<stdio.h>
#include<sys/types.h>
int main()
{
	int *p1,*p2,*p3,*p4;
printf("sbrk(0) before malloc(4): 0x%x \n" ,sbrk(0));
p1=(int *) malloc(4);
printf("sbrk(0) after `p1 = (int *) malloc(4)':0x%x\n",sbrk(0));
p2=(int *) malloc (4);
printf("sbrk(0) after `p2 = (int *) malloc(4)':0x%x\n",sbrk(0));
p3=(int *) malloc (4);
printf("sbrk(0) after `p3 = (int *) malloc(4)':0x%x\n",sbrk(0));
p4=(int *) malloc (4);
printf("sbrk(0) after `p4 = (int *) malloc(4)':0x%x\n",sbrk(0));
printf("p1=0x%l, p2=0x%l, p3=0x%l, p4=0x%l \n",p1,p2,p3,p4);
return 0;

}
